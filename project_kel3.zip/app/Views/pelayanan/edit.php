<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <title>Tambah Pelayanan</title>
</head>
<body>
    <h2>Tambah Pelayanan</h2>
    <form action="/pelayanan/store" method="post">
        <div class="form-group row">
            <div class="col-xs-3">
        <label>Nama Pelayanan:</label>
        <input type="text" class="form-control" name="nama_pelayanan" required><br>
        <button type="submit" style="background-color:LightGray;" class="btn">Simpan</button>
            </div>
        </div>
    </form>
</body>
</html>