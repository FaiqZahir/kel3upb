<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Antrian</title>
</head>
<body>
    <?= $this->include('layout/header') ?>
<h2>Tambah Antrian</h2>
<form method="post" action="/antrian/store">
    <div class="form-group row">
        <div class="col-xs-4">
    <label>Nomor Antrian:</label> <input type="text" name="nomor_antrian" required><br>
    <label>Nama Pengunjung:</label> <input type="text" name="nama_pengunjung" required><br>
    <label>Pelayanan:</label>
    <select name="id_pelayanan">
        <?php foreach ($pelayanan as $p): ?>
            <option value="<?= $p['id'] ?>"><?= $p['nama_pelayanan'] ?></option>
        <?php endforeach; ?>
    </select><br>
    <label>Loket:</label>
    <select name="id_loket">
        <?php foreach ($loket as $l): ?>
            <option value="<?= $l['id'] ?>"><?= $l['nama_loket'] ?></option>
        <?php endforeach; ?>
    </select><br>
    <label>Waktu:</label> <input type="datetime-local" name="waktu" required><br>
        </div>
    </div>
    <button type="submit">Simpan</button>
</form>
</body>
</html>